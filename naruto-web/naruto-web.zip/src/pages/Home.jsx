import React from "react";

const Home = () => {
  return <div>Este es el home</div>;
};

export default Home;
